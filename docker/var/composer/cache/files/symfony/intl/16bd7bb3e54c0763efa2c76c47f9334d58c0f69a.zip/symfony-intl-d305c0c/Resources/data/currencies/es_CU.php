<?php

return [
    'Names' => [
        'CUP' => [
            0 => '$',
            1 => 'peso cubano',
        ],
        'USD' => [
            0 => 'US$',
            1 => 'dólar estadounidense',
        ],
    ],
];
