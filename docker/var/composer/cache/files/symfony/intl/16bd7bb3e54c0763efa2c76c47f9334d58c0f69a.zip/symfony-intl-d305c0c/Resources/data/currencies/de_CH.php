<?php

return [
    'Names' => [
        'BYN' => [
            0 => 'BYN',
            1 => 'Weissrussischer Rubel',
        ],
        'BYR' => [
            0 => 'BYR',
            1 => 'Weissrussischer Rubel (2000–2016)',
        ],
        'EUR' => [
            0 => 'EUR',
            1 => 'Euro',
        ],
        'STN' => [
            0 => 'STN',
            1 => 'São-toméischer Dobra (2018)',
        ],
    ],
];
