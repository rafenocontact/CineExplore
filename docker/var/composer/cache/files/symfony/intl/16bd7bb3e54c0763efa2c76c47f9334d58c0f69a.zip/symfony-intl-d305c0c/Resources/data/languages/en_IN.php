<?php

return [
    'Names' => [
        'bn' => 'Bengali',
    ],
    'LocalizedNames' => [
        'ro_MD' => 'Moldavian',
    ],
];
