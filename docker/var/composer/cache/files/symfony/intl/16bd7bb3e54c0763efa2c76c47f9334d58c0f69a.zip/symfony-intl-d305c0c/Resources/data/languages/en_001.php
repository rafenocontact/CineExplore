<?php

return [
    'Names' => [
        'mus' => 'Creek',
        'sah' => 'Yakut',
    ],
    'LocalizedNames' => [
        'nds_NL' => 'West Low German',
    ],
];
