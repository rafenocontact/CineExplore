<?php

return [
    'Names' => [
        'MWK' => [
            0 => 'MK',
            1 => 'Malawian Kwacha',
        ],
    ],
];
