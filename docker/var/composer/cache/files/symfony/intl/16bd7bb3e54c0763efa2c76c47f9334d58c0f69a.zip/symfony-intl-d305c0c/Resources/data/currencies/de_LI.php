<?php

return [
    'Names' => [
        'EUR' => [
            0 => 'EUR',
            1 => 'Euro',
        ],
    ],
];
