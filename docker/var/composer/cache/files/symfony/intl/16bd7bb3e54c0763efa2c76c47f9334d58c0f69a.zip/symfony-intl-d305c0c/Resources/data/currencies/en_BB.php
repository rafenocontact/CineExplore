<?php

return [
    'Names' => [
        'BBD' => [
            0 => '$',
            1 => 'Barbadian Dollar',
        ],
    ],
];
