<?php

return [
    'Names' => [
        'MRU' => [
            0 => 'UM',
            1 => 'Ugiyya Muritani',
        ],
    ],
];
