<?php

return [
    'Names' => [
        'NGN' => [
            0 => '₦',
            1 => 'Nigerian Naira',
        ],
    ],
];
