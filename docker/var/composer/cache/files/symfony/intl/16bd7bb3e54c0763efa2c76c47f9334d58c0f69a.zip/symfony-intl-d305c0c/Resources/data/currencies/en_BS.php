<?php

return [
    'Names' => [
        'BSD' => [
            0 => '$',
            1 => 'Bahamian Dollar',
        ],
    ],
];
