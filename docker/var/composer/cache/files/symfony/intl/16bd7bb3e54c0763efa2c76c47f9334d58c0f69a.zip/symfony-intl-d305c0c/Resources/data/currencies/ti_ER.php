<?php

return [
    'Names' => [
        'ERN' => [
            0 => 'Nfk',
            1 => 'ናቕፋ',
        ],
    ],
];
