<?php

declare(strict_types=1);

namespace Doctrine\Migrations\Metadata\Storage;

interface MetadataStorageConfiguration
{
}
