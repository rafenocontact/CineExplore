<?php

namespace Doctrine\Common\Proxy\Exception;

/**
 * Base exception interface for proxy exceptions.
 *
 * @link   www.doctrine-project.org
 */
interface ProxyException
{
}
